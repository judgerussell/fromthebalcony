H = 60
W = 80
imgx = W/2
imgy = H/2
c1x = 0
c2x = 30

menu = {}

function menu.load()
	love.graphics.setDefaultFilter( "nearest" )
	c1 = love.graphics.newImage("cloud2.png")
	c2 = love.graphics.newImage("cloud2.png")
	font = love.graphics.newFont(42)
	love.graphics.setFont(font)
	love.graphics.setBackgroundColor(112/255, 174/255, 218/255)

	frames = {}

	for i=1,3 do
		table.insert(frames, love.graphics.newImage("building" .. i .. ".png"))
	end
	table.insert(frames, love.graphics.newImage("building2.png"))

	currentFrame = 1
end

function menu.update(dt)
	c1x = c1x + 2 * dt
	c2x = c2x + 4 * dt

	if c1x > W then
		c1x = 0
	end

	if c2x > 50 + W then
		c2x = 50
	end

	currentFrame = currentFrame + 5 * dt
	if currentFrame > 5 then
		currentFrame = 1
	end
end

function menu.draw()	



	love.graphics.scale(10, 10)
	love.graphics.draw(frames[math.floor(currentFrame)], W*(5/8), H*(3/8), 0, (5/6), (5/6))


	love.graphics.draw(c1, c1x, 5)
	love.graphics.draw(c2, c2x, 30, 0, .75, .75)

	if c1x + c1:getWidth() > W then
		love.graphics.draw(c1, c1x - W, 5)
	end

	if c2x + c2:getWidth() > W then
		love.graphics.draw(c2, c2x - W, 30, 0, .75, .75)
	end

	love.graphics.scale(.1, .1)
	love.graphics.print("from the balcony", 50, 500)

	
end

function menu.mousepressed(x, y, button, istouch)
	require_state("game")
	change_state(game)
end

function menu.keypressed(x, y, button, istouch)
	require_state("game")
	change_state(game)
end