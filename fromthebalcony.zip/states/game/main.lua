game = {}

camera = {}
camera.x = 0
camera.y = 0
camera.scaleX = .1
camera.scaleY = .1
scaling_factor = 8

function camera:set()
	love.graphics.push()
	love.graphics.translate(-self.x, -self.y)
end

function camera:unset()
	love.graphics.pop()
end

function camera:setPosition(x, y)
	self.x = (x - W) * self.scaleX or self.x
	self.y = (y - H) * self.scaleY or self.y
end

function camera:mousePosition()
  return love.mouse.getX() + self.x, love.mouse.getY() + self.y
end

function game.load()
	font = love.graphics.newFont(12)
	love.graphics.setFont(font)
	birds = {}
	bbuilding = love.graphics.newImage("bbuilding.png")
	bbuilding1 = love.graphics.newImage("bbuilding1.png")
	bbuilding1_on = love.graphics.newImage("bbuildinglight.png")
	bird = love.graphics.newImage("pigeon.png")
	lighton = false

	chords = {}
	sounds = {}

	table.insert(sounds, love.audio.newSource("sounds/meow.ogg", "static"))

	for i=1,5 do
    	table.insert(chords, love.audio.newSource("chords/" .. i .. ".ogg", "static"))
    end

	bbuilding_frames = {}
	bbuilding1_frames = {}
	bbuilding1_frames_on = {}
	bird_frames = {}

	local frame_width = 32
	local frame_height = 64

	for i=0,3 do
		 table.insert(bbuilding_frames, love.graphics.newQuad(i * frame_width, 0, frame_width, frame_height, bbuilding))
	end

	for i=0,3 do
		 table.insert(bbuilding1_frames, love.graphics.newQuad(i * frame_width, 0, frame_width, frame_height, bbuilding1))
	end

	for i=0,3 do
		 table.insert(bbuilding1_frames_on, love.graphics.newQuad(i * frame_width, 0, frame_width, frame_height, bbuilding1_on))
	end

	local frame_width = 3
	local frame_height = 3

	for i=0,3 do
		 table.insert(bird_frames, love.graphics.newQuad(i * frame_width, 0, frame_width, frame_height, bird))
	end

	currentFrame = 1
end

function game.update(dt)
	currentFrame = currentFrame + 5 * dt
	if currentFrame > 5 then
		currentFrame = 1
	end

	for i, b in ipairs(arrayRemove(birds, birdsInBounds)) do
		b.x = b.x - 40 * dt
		b.y = b.y - 40 * dt
	end

	camera:setPosition(camera:mousePosition())
end 	

function game.draw()

	camera:set()
	love.graphics.scale(scaling_factor, scaling_factor)

	for i=0,8 do
		if i == 3 then
			if lighton then
				love.graphics.draw(bbuilding1_on, bbuilding1_frames_on[math.floor(currentFrame)], (i - 1) * 32, 20)
			else
				love.graphics.draw(bbuilding1, bbuilding1_frames[math.floor(currentFrame)], (i - 1) * 32, 20)
			end
		else
			love.graphics.draw(bbuilding, bbuilding1_frames_on[math.floor(currentFrame)], (i - 1) * 32, 20)
		end
	end
	for i, b in ipairs(birds) do
		love.graphics.draw(bird, bird_frames[math.floor(currentFrame)], b.x/scaling_factor, b.y/scaling_factor )
	end



	camera:unset()
end

function makeBird(x, y)
	b = {}
	b.x = x
	b.y = y
	table.insert(birds, b)
end


function game.mousepressed(x, y, button, istouch) 
	love.audio.stop()
	makeBird(x, y)
	love.audio.play(chords[2])
end

function game.keypressed(key, scancode, r)
	if key == "space" then
		love.audio.stop()
		lighton = not lighton
		if lighton then
			love.audio.play(chords[3])
		else
			love.audio.play(chords[5])
		end
	end
end

function arrayRemove(t, fnKeep)
	local j, n = 1, #t

	for i=1, n do
		if(fnKeep(t, i, j)) then
			if i ~= j then
				t[j] = t[i]
				t[i] = nil
			end
			j = j + 1
		else
			t[i] = nil
		end
	end

	return t
end

function birdsInBounds(b, i, j)
	if b[i].x < -20 or b[i].y < -20 then
		return false
	elseif lighton and b[i].x < 92 * scaling_factor and b[i].x > 85 * scaling_factor and b[i].y < 45 * scaling_factor and b[i].y > 40 * scaling_factor then
		love.audio.play(sounds[1])
		return false
	else 
		return true
	end
end