local state = nil

function clearLoveCallbacks()
	love.draw = nil
	love.joystickpressed = nil
	love.joystickreleased = nil
	love.keypressed = nil
	love.keyreleased = nil
	love.mousepressed = nil
	love.mousereleased = nil
	love.update = nil
end

function change_state(s)
	state = s
	state.load()
end

function require_state(s)
	local path = "states/" .. s .. "/main"
	require(path)
end


function love.load()
	require_state("menu")
	change_state(menu)
end

function love.draw() state.draw() end
function love.update(dt) state.update(dt) end
function love.mousepressed(x, y, button, istouch) state.mousepressed(x, y, button, istouch) end
function love.keypressed(key, scancode, r) state.keypressed(key, scancode, r) end